# Data /  icons float nodes connect infographic: GSAP

A Pen created on CodePen.

Original URL: [https://codepen.io/dermalhealth/pen/GgNNPQJ](https://codepen.io/dermalhealth/pen/GgNNPQJ).

