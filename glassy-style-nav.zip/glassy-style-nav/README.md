# glassy style nav

A Pen created on CodePen.

Original URL: [https://codepen.io/LeonLinBuild/pen/emdgRJj](https://codepen.io/LeonLinBuild/pen/emdgRJj).

