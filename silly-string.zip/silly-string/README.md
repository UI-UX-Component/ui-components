# Silly String

A Pen created on CodePen.

Original URL: [https://codepen.io/SultanKhanCQ/pen/KwgxROB](https://codepen.io/SultanKhanCQ/pen/KwgxROB).

Spray silly string on the CodePen logo. Verlet physics with pixel-perfect SVG collision. Hold & drag to spray.