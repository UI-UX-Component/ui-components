# Hero Capturing moments gallery carousel: GSAP

A Pen created on CodePen.

Original URL: [https://codepen.io/dermalhealth/pen/KwNXWZb](https://codepen.io/dermalhealth/pen/KwNXWZb).

