# The Shore Shack — Beach Sandwich Bar Menu #CodepenChallenge

A Pen created on CodePen.

Original URL: [https://codepen.io/jerora98/pen/KwNNyjg](https://codepen.io/jerora98/pen/KwNNyjg).

A fully responsive restaurant menu layout for the May 2026 CodePen Challenge. 
Features a live category filter (Sandwiches / Bowls / Sides / Drinks), 
ingredient & nutrition tooltips on hover, animated wave dividers, 
a Today's Special section, custom cursor, scroll reveal animations, 
marquee strip, and a mobile hamburger nav — all in a fresh coastal aesthetic 
built with vanilla HTML, CSS & JS. No frameworks, no dependencies.